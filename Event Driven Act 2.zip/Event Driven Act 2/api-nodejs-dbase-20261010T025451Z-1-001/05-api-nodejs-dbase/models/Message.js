const db = require("./db");

const FIELDS = [
  "fld_recno",
  "fld_user_id",
  "fld_message",
  "fld_timestamp"
];

const Message = {
  async all() {
    const [rows] = await db.execute("SELECT * FROM tbl_messages");
    return rows;
  },

  async find(id) {
    const [rows] = await db.execute(
      "SELECT * FROM tbl_messages WHERE fld_recno=?",
      [id]
    );
    return rows;
  },

  async findByUser(userId) {
    const [rows] = await db.execute(
      "SELECT * FROM tbl_messages WHERE fld_user_id=?",
      [userId]
    );
    return rows;
  }
};

module.exports = Message;
