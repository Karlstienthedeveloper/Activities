const db = require("./db");

const FIELDS = [
  "fld_recno",
  "fld_lname",
  "fld_mname",
  "fld_fname",
  "fld_extname",
  "fld_user_id"
];

const User = {
  async all() {
    const [rows] = await db.execute("SELECT * FROM tbl_users");
    return rows;
  },

  async find(id) {
    const [rows] = await db.execute(
      "SELECT * FROM tbl_users WHERE fld_recno=? OR fld_user_id=?",
      [id, id]
    );
    return rows;
  }
}

module.exports = User;