const Message = require("../models/Message");

exports.getMessages = async (req, res) => {
  try {
    res.json({ success: true, data: await Message.all() });
  } catch (er) {
    res.status(500).json({ success: false, error: er.message });
  }
};

exports.getMessage = async (req, res) => {
  try {
    const message = await Message.find(req.params.id);
    if (!message || message.length === 0) {
      return res.status(404).json({ success: false, error: "Message not found" });
    }
    res.json({ success: true, data: message[0] || message });
  } catch (er) {
    res.status(500).json({ success: false, error: er.message });
  }
};

exports.getUserMessages = async (req, res) => {
  try {
    const messages = await Message.findByUser(req.params.userId);
    res.json({ success: true, data: messages });
  } catch (er) {
    res.status(500).json({ success: false, error: er.message });
  }
};
