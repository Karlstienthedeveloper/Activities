CREATE DATABASE IF NOT EXISTS db_activity2;
USE db_activity2;

CREATE TABLE IF NOT EXISTS tbl_users (
  fld_recno INT AUTO_INCREMENT PRIMARY KEY,
  fld_lname VARCHAR(100) NOT NULL,
  fld_mname VARCHAR(100) DEFAULT '',
  fld_fname VARCHAR(100) NOT NULL,
  fld_extname VARCHAR(20) DEFAULT '',
  fld_user_id VARCHAR(50) NOT NULL UNIQUE,
  INDEX idx_user_id (fld_user_id)
);

CREATE TABLE IF NOT EXISTS tbl_messages (
  fld_recno INT AUTO_INCREMENT PRIMARY KEY,
  fld_user_id VARCHAR(50) NOT NULL,
  fld_message TEXT NOT NULL,
  fld_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_messages_user_id (fld_user_id),
  CONSTRAINT fk_messages_users FOREIGN KEY (fld_user_id) REFERENCES tbl_users(fld_user_id) ON DELETE CASCADE ON UPDATE CASCADE
);

-- 3 sample records for tbl_users
INSERT INTO tbl_users (fld_lname, fld_mname, fld_fname, fld_extname, fld_user_id) VALUES
('Dela Cruz', 'Santos', 'Juan', '', 'USR-101'),
('Reyes', 'Garcia', 'Maria', 'Jr.', 'USR-102'),
('Aquino', 'Mendoza', 'Jose', 'III', 'USR-103');

-- 3 sample records for tbl_messages
INSERT INTO tbl_messages (fld_user_id, fld_message) VALUES
('USR-101', 'Welcome to Event Driven Programming Activity 2.'),
('USR-102', 'Database connection and foreign key link verified.'),
('USR-103', 'User indexing and message records loaded successfully.');
